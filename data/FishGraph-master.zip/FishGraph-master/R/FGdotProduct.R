FGdotProduct <-
function(x,y) as.numeric(crossprod(x,y))

