FGMakeTitle <-
function(Text, DataName)
    {   paste(Text, "       Data: ", DataName, sep = "")
    }

